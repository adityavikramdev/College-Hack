<html>
    <head>
        <title>COLLEGE HACK</title>


   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"  >
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" type="text/css" href="style.css">
      </head>
      <body>
          <?php 
          require 'includes/header.php';
          ?>
                <div class="container">
                      <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="modal-title" style="color:#000000; text-allign:center;"><h2>LogIn Form</h2><h4>(Only For Service Providers)</h4></div>
      </div>
      <div class="modal-body">
        <div class="row">

                <form>
                    <div class="form-group" style="margin:0px 10px 0px 10px;">
                        <input type="text" class="form-control" placeholder="Username" name="Username">
                        <br>
                        <input type="password" class="form-control" placeholder="Password" name="password">
                        <br>
                        <input type="submit" value="LogIn" class="btn btn-primary">
                        </div>
                    </div>
            </div>
      </div>
    </div>
    </div>
                          </div>
                          <div class="container">
                            <div class="row">
                              <div class="col-xs-offset-2 col-xs-8 col-sm-8 col-lg-8">
                                <div class="jumbotron">
                                  <center><h1>OUR TEAM!</h1></center>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="container">
                            <div class="row">
                              <div class="col-xs-4 col-sm-4 col-lg-4">
                                <div class="thumbnail">
                                  <img src="img/photo.jpg" class="img-rounded" alt="Nishtha Goswami">
                                  <div class="text-caption"><center><h3>NISHTHA GOSWAMI</h3><a href="mailto:n1234@gmail.com" target="_blank"><h4>Contact:nish0349@gmail.com</h4></a></center></div>
                                  </div>
                                </div>
                                <div class="col-xs-4 col-sm-4 col-lg-4">
                                  <div class="thumbnail">
                                      <img src="img/IMG_20180218_130516.jpg" class="img-rounded" alt="Chaitanya Ashish Mishra" style="height:350px; width:100%;">
                                    <div class="text-caption"><center><h3>CHAITANYA ASHISH MISHRA</h3><a href="mailto:chaitanyaashish97@gmail.com" target="_blank"><h4>Contact:chaitanyaashish97@gmail.com</h4></a></center></div>
                                    </div>
                                  </div>
                                  <div class="col-xs-4 col-sm-4 col-lg-4">
                                    <div class="thumbnail">
                                        <img src="img/name.jpg" class="img-rounded" alt="Aditya Vikram Dev" style="height:350px;">
                                      <div class="text-caption"><center><h3>ADITYA VIKRAM DEV</h3><a href="mailto:avd0617@gmail.com" target="_blank"><h4>Contact:avd0617@gmail.com</h4></a></center></div>
                                      </div>
                                    </div>
                              </div>
                            </div>
                          </body>
                        </html>