<?php
require 'includes/common.php';
$id=$_GET['idid'];
$user=$_GET['user'];
$pass=$_GET['pass'];
echo "$id,$user,$pass";
?>