<form method="get" action="test1.php">
    <div class="form-group">
        <input type="text" id="idid" name="idid" value="1"  readonly class="form-control">
                   </div>
                   <div class="form-group">
                       <input type="text" name="user"  class="form-control" placeholder="Username">
                   </div>
                   <div class="form-group">
                       <input type="password" name="pass" class="form-control" placeholder="Password">
                   </div>
                   <div class="form-group">
                       <input type="number" name="contact" class="form-control" placeholder="Contact">
                   </div>
                   <div class="form-group">
                       <button type="submit" class="form-control btn btn-primary">Sign In</button>
                   </div>
</form>
