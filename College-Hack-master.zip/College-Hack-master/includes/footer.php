<html>   
    <head>
        <link href="bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <script src="bootstrap-3.3.7-dist/js/jquery-3.2.1.min.js" type="text/javascript"></script>
        <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js" type="text/javascript"></script>
    </head>
    <body>
           <footer>
             <center>
             <p><b>For any new business,Please </b><a href="../contactus.php" target="_blank" style="color:#000000;">Conatct Us</a><b>||&copy; CopyRight@</b></p>
           </center>
             </footer>
    </body>
</html>