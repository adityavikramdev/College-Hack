Application Name: COLLEGE HACK

Project Description:
Our website provides a platform for the students to know about the scenario or the facilitiess like canteen, dispensary, stationary etc. available in the campus from their hostel room and tackle the following problems:
-Due to fluctuations in the timings as well as the menu of the canteen or mess, so in order to solve this probem we in our website will display if the canteen is open or not and what are the available items present at that moment.
-Students in need of medical care can find out which doctors along with their specialization are present in the college dispensary.
-Our website also informs the students about the upcoming events and the important news feed related to examinations and other important notices.

In order to use certain services, we have created a repository of our project on IBM Cloud and further DevOps(a local git repository) can be used to pipeline and migrate the project to bluemis.net.

Platform Dependencies:
WAMP Server which is the Apache MYSQL-PHP stack in order to run the backend on PHP and manage MySQL and the UX.
UX/UI used Bootstrap, JQuery

We have used NetBeans 8.2 IDE and Atom Text Editor to test and run the code. The backend is deployed on the localhost through WAMP using PHP integrating the database MYSQL using MySQLi.

Nishtha Goswami - nish0349@gmail.com
Chaitanya Ashish Mishra - chaitanyaashish97@gmail.com
Aditya Vikram Dev - avd0617@gmail.com



